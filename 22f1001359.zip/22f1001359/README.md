# BlogLite

### Steps to run the application
- Extract the folder
- Open folder in command line.
- Install python
- Run the command pip install -r requirements.txt to install necessary packages
- Run the app.py file
